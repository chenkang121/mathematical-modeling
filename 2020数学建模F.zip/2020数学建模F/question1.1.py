import pandas as pd
import numpy as np
from math import tan, pi, sqrt, atan


def to_radian(angel):
    radian = angel/180*pi
    return radian

box_data = pd.read_excel('data\\附件1-飞行器参数.xlsx', sheet_name='Sheet1')
box_message = box_data.values
time_data = pd.read_excel('data\\question1_data_processed.xlsx', index_col=0)
# print(time_data)

print(box_data)
# print(box_message.shape)

oil_density = 850
# 计算装油邮箱倾斜后的质心


# def calCentroid(alpha, box_message, oil_volume):
#     mass = oil_volume*oil_density
#     centroid = (0, 0, 0)
#     return centroid, mass
'''
h0 = oil0/s1*c1
    h1_l = h0 - a1/2*tan(to_radian(alpha0))
    h1_r = h0 + a1/2*tan(to_radian(alpha0))
    flag_trapezoid = 1
    if (h1_l < 0) or (h1_r < 0):
        flag_trapezoid = 0
        if oil0 > 0.5 * s1:
            pass
        else:
            pass



    if (h1_l > c1) or (h1_r > c1):
        flag_trapezoid = 0
        if oil0 > 0.5 * s1:
            pass
        else:
            pass

    if flag_trapezoid == 1:
        print('是梯形！')
#     是梯形
        if h1_r >= h1_l:
            a = h1_l
            b = h1_r
            h = a1
            x1 = -h*(2*a+b)/((a+b)*3)
            z1 = (a**2 + b**2 + a*b)/(3*(a+b))
            x0 = -a1/2
            z0 = c1/2
            bais_x = x1-x0
            bais_z = z1-z0
        else:
            a = h1_r
            b = h1_l
            h = a1
            x1 = h * (2 * a + b) / ((a + b) * 3)
            z1 = (a ** 2 + b ** 2 + a * b) / (3 * (a + b))
            x0 = a1 / 2
            z0 = c1 / 2
            bais_x = x1 - x0
            bais_z = z1 - z0
'''


def calCentriod(box_name, oil0, alpha0):

    a = box_message[box_name, 3]
    b = box_message[box_name, 4]
    c = box_message[box_name, 5]

    centroid0_x = box_message[box_name, 0]
    centroid0_y = box_message[box_name, 1]
    centroid0_z = box_message[box_name, 2]
    alpha0 = to_radian(alpha0)
    mass = oil0*oil_density

    if alpha0 == 0:
        bais_x, bais_z = (0, oil0/(b*a)-c/2)

    # print(box_name)
    if alpha0 > 0:
        if abs(alpha0) <= atan(c/a):
            if oil0/b <= 0.5*a*a*tan(alpha0):

                x0, z0 = (-a/2, -c/2)
                x1, z1 = (x0 + sqrt(2*oil0/(b*abs(tan(alpha0)))), -c/2)
                x2, z2 = (-a/2, z0 + sqrt(2*(oil0/b)*abs(tan(alpha0))))
                # print(sqrt(2*oil0/(b*abs(tan(alpha0)))), sqrt(2*(oil0/b)*abs(tan(alpha0))))
                bais_x, bais_z = ((x0+x1+x2)/3, (z0+z1+z2)/3)
                if abs(bais_x) > a/2 or abs(bais_z) > c/2:
                    print(1, bais_x, bais_z)

            if oil0/b > 0.5*a*a*tan(alpha0) and oil0/b <= a*c - 0.5*a*a*tan(alpha0):
                a1 = ((oil0/b)-0.5*(a*a*abs(tan(alpha0))))/a
                b1 = ((oil0/b)-0.5*(a*a*abs(tan(alpha0))))/a + a*abs(tan(alpha0))
                h = a
                # print(box_name, a1, b1, alpha0, oil0)
                x0, z0 = (-a/2, -c/2)
                x1, z1 = ((1/3)*h*(2*a1+b1)/(a1+b1), (1/3)*(a1**2+b1**2+a1*b1)/(a1+b1))
                bais_x, bais_z = (x0+x1, z0+z1)
                if abs(bais_x) > a/2 or abs(bais_z) > c/2:
                    print(2, bais_x, bais_z)
            if oil0/b > a*c - 0.5*a*a*tan(alpha0) and oil0/b <= a*c:
                a_delta_up = sqrt(2*(a*c-oil0/b)/abs(tan(alpha0)))
                h_delta_right = sqrt(2*(a*c-oil0/b)*abs(tan(alpha0)))


                x0, z0 = (-a_delta_up/2, 0)
                s_rec = c*(a-a_delta_up)

                a1 = c-h_delta_right
                b1 = c
                h = a_delta_up

                x1, z1 = ((1 / 3) * h * (2 * a1 + b1) / (a1 + b1), (1 / 3) * (a1 ** 2 + b1 ** 2 + a1 * b1) / (a1 + b1))
                x2, z2 = (a/2-a_delta_up, -c/2)
                x3, z3 = (x1+x2, z1+z2)
                s_tri = h*(a1+b1)/2

                vec_x, vec_z = (x3-x0, z3-z0)
                p = s_tri/(s_rec+s_tri)

                bais_x, bais_z = (x0 + p*vec_x, z0 + p*vec_z)

                if abs(bais_x) > a/2 or abs(bais_z) > c/2:
                    print(3, bais_x, bais_z)

        if abs(alpha0) > atan(c/a):
            if oil0/b <= 0.5*c*c/tan(alpha0):
                x0, z0 = (-a / 2, -c / 2)
                x1, z1 = (x0 + sqrt(2 * oil0 / (b * abs(tan(alpha0)))), -c / 2)
                x2, z2 = (-a / 2, z0 + sqrt(2 * (oil0 / b) * abs(tan(alpha0))))
                bais_x, bais_z = ((x0 + x1 + x2) / 3, (z0 + z1 + z2) / 3)
                if abs(bais_x) > a/2 or abs(bais_z) > c/2:
                    print(4, bais_x, bais_z)

            if oil0/b > 0.5*c*c/tan(alpha0) and oil0/b <= a*c -  0.5*c*c/tan(alpha0):
                a1 = ((oil0/b-0.5*c*c/abs(tan(alpha0)))*(a-c/abs(tan(alpha0))))/(a*c-c*c/abs(tan(alpha0)))
                b1 = a1 + c/abs(tan(alpha0))
                h = c
                x0, z0 = (-a / 2, -c / 2)
                x1, z1 = ((1 / 3) * (a1 ** 2 + b1 ** 2 + a1 * b1) / (a1 + b1), (1 / 3) * h * (2 * a1 + b1) / (a1 + b1))
                bais_x, bais_z = (x0 + x1, z0 + z1)
                if abs(bais_x) > a/2 or abs(bais_z) > c/2:
                    print(5, bais_x, bais_z)


            if oil0/b > a*c -  0.5*c*c/tan(alpha0) and oil0/b <= a*c:
                a_delta_up = sqrt(2 * (a * c - oil0 / b) / abs(tan(alpha0)))
                h_delta_right = sqrt(2 * (a * c - oil0 / b) * abs(tan(alpha0)))

                x0, z0 = (-a_delta_up / 2, 0)
                s_rec = c * (a - a_delta_up)

                a1 = c - h_delta_right
                b1 = c
                h = a_delta_up

                x1, z1 = ((1 / 3) * h * (2 * a1 + b1) / (a1 + b1), (1 / 3) * (a1 ** 2 + b1 ** 2 + a1 * b1) / (a1 + b1))
                x2, z2 = (a / 2 - a_delta_up, -c / 2)
                x3, z3 = (x1 + x2, z1 + z2)
                s_tri = h * (a1 + b1) / 2

                vec_x, vec_z = (x3 - x0, z3 - z0)
                p = s_tri / (s_rec + s_tri)

                bais_x, bais_z = (x0 + p * vec_x, z0 + p * vec_z)
                if abs(bais_x) > a/2 or abs(bais_z) > c/2:
                    print(6, bais_x, bais_z)
    if alpha0 < 0:
        if abs(alpha0) <= atan(c/a):
            if oil0/b <= 0.5*a*a*abs(tan(alpha0)):
                x0, z0 = (a / 2, -c / 2)
                x1, z1 = (x0 - sqrt(2 * oil0 / (b * abs(tan(alpha0)))), c / 2)
                x2, z2 = (a / 2, z0 + sqrt(2 * (oil0 / b) * abs(tan(alpha0))))
                bais_x, bais_z = ((x0 + x1 + x2) / 3, (z0 + z1 + z2) / 3)
                if abs(bais_x) > a/2 or abs(bais_z) > c/2:
                    print(7, bais_x, bais_z)
            if oil0/b > 0.5*a*a*abs(tan(alpha0)) and oil0/b <= a*c - 0.5*a*a*abs(tan(alpha0)):
                a1 = ((oil0 / b) - 0.5 * (a * a * abs(tan(alpha0))))/a

                b1 = ((oil0 / b) - 0.5 * (a * a * abs(tan(alpha0))))/a + a * abs(tan(alpha0))
                # print(a1, b1)
                h = a
                x0, z0 = (a / 2, -c / 2)
                x1, z1 = ((1 / 3) * h * (2 * a1 + b1) / (a1 + b1), (1 / 3) * (a1 ** 2 + b1 ** 2 + a1 * b1) / (a1 + b1))
                bais_x, bais_z = (x0 - x1, z0 + z1)

                if abs(bais_x) > a/2 or abs(bais_z) > c/2:

                    print(8, bais_x, bais_z, box_name, a, c, a1, b1)

            if oil0/b > a*c - 0.5*a*a*abs(tan(alpha0)) and oil0/b <= a*c:
                a_delta_up = sqrt(2 * (a * c - oil0 / b) / abs(tan(alpha0)))
                h_delta_right = sqrt(2 * (a * c - oil0 / b) * abs(tan(alpha0)))

                x0, z0 = (-a_delta_up / 2, 0)
                s_rec = c * (a - a_delta_up)

                a1 = c - h_delta_right
                b1 = c
                h = a_delta_up

                x1, z1 = ((1 / 3) * h * (2 * a1 + b1) / (a1 + b1), (1 / 3) * (a1 ** 2 + b1 ** 2 + a1 * b1) / (a1 + b1))
                x2, z2 = (a / 2 - a_delta_up, -c / 2)
                x3, z3 = (x1 + x2, z1 + z2)
                s_tri = h * (a1 + b1) / 2

                vec_x, vec_z = (x3 - x0, z3 - z0)
                p = s_tri / (s_rec + s_tri)

                bais_x, bais_z = (-(x0 + p * vec_x), z0 + p * vec_z)
                if abs(bais_x) > a/2 or abs(bais_z) > c/2:
                    print(9, bais_x, bais_z)
        if abs(alpha0) > atan(c/a):
            if oil0/b <= 0.5*c*c/abs(tan(alpha0)):
                x0, z0 = (-a / 2, -c / 2)
                x1, z1 = (x0 + sqrt(2 * oil0 / (b * abs(tan(alpha0)))), -c / 2)
                x2, z2 = (-a / 2, z0 + sqrt(2 * (oil0 / b) * abs(tan(alpha0))))
                bais_x, bais_z = (-(x0 + x1 + x2) / 3, (z0 + z1 + z2) / 3)
                if abs(bais_x) > a/2 or abs(bais_z) > c/2:
                    print(10, bais_x, bais_z)
            if oil0/b > 0.5*c*c/abs(tan(alpha0)) and oil0/b <= a*c -  0.5*c*c/abs(tan(alpha0)):
                a1 = ((oil0 / b - 0.5 * c * c / abs(tan(alpha0))))/c
                b1 = a1 + c/abs(tan(alpha0))
                h = c
                x0, z0 = (-a / 2, -c / 2)
                x1, z1 = ((1 / 3) * (a1 ** 2 + b1 ** 2 + a1 * b1) / (a1 + b1), (1 / 3) * h * (2 * a1 + b1) / (a1 + b1))
                bais_x, bais_z = (-(x0 + x1), z0 + z1)
                if abs(bais_x) > a/2 or abs(bais_z) > c/2:
                    print(11, bais_x, bais_z)
            if oil0/b > a*c -  0.5*c*c/abs(tan(alpha0)) and oil0/b <= a*c:
                a_delta_up = sqrt(2 * (a * c - oil0 / b) / abs(tan(alpha0)))
                h_delta_right = sqrt(2 * (a * c - oil0 / b) * abs(tan(alpha0)))

                x0, z0 = (-a_delta_up / 2, 0)
                s_rec = c * (a - a_delta_up)

                a1 = c - h_delta_right
                b1 = c
                h = a_delta_up

                x1, z1 = ((1 / 3) * h * (2 * a1 + b1) / (a1 + b1), (1 / 3) * (a1 ** 2 + b1 ** 2 + a1 * b1) / (a1 + b1))
                x2, z2 = (a / 2 - a_delta_up, -c / 2)
                x3, z3 = (x1 + x2, z1 + z2)
                s_tri = h * (a1 + b1) / 2

                vec_x, vec_z = (x3 - x0, z3 - z0)
                p = s_tri / (s_rec + s_tri)

                bais_x, bais_z = (-(x0 + p * vec_x), z0 + p * vec_z)
                if abs(bais_x) > a/2 or abs(bais_z) > c/2:
                    print(12, bais_x, bais_z)
    # if abs(bais_x) > 0.5*a:
    #     print(bais_x, bais_z, oil0, box_name, alpha0)
    # if abs(bais_z) > 0.5*c:
    #     print(bais_x, bais_z, oil0, box_name, alpha0)
    return (centroid0_x + bais_x, centroid0_y, centroid0_z + bais_z), mass


posCentriod_time = {
    'box1_x': [], 'box1_y': [], 'box1_z': [], 'box1_mass': [],
    'box2_x': [], 'box2_y': [], 'box2_z': [], 'box2_mass': [],
    'box3_x': [], 'box3_y': [], 'box3_z': [], 'box3_mass': [],
    'box4_x': [], 'box4_y': [], 'box4_z': [], 'box4_mass': [],
    'box5_x': [], 'box5_y': [], 'box5_z': [], 'box5_mass': [],
    'box6_x': [], 'box6_y': [], 'box6_z': [], 'box6_mass': [],
}

for time in range(time_data.shape[0]):
    alpha0 = time_data.iloc[time, -1]
    for box_name in range(6):
        oil0 = time_data.iloc[time, box_name]/oil_density
        posCentriod, mass = calCentriod(box_name, oil0, alpha0)

        # print(box_name+1, posCentriod, mass)
        posCentriod_time['box%d_x' % (box_name+1)].append(posCentriod[0])
        posCentriod_time['box%d_y' % (box_name+1)].append(posCentriod[1])
        posCentriod_time['box%d_z' % (box_name+1)].append(posCentriod[2])
        posCentriod_time['box%d_mass' % (box_name+1)].append(mass)

posCentriod_time = pd.DataFrame(posCentriod_time)
posCentriod_time.to_excel('data\\question1.1posCentriod_time.xlsx')