import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

data = pd.read_excel('data\\question4_visual_centroid.xlsx')
val = data.values

print(data)
ax = plt.axes(projection='3d')
ax.scatter3D(val[0, 0], val[0, 1], val[0, 2], c='r')
ax.scatter3D(val[:, 0], val[:, 1], val[:, 2], alpha=0.08)
ax.scatter3D(val[:, 3], val[:, 4], val[:, 5], alpha=0.04)


plt.show()


