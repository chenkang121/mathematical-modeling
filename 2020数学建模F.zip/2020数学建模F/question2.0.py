import pandas as pd
import numpy as np


e_data = pd.read_excel('data\\附件3-问题2数据.xlsx', sheet_name='飞行器理想质心数据')
need_data = pd.read_excel('data\\附件3-问题2数据.xlsx', sheet_name='发动机耗油速度')
# print(e_data.values)
# print(need_data)
v_max = np.array([1.1, 1.8, 1.7, 1.5, 1.6, 1.1])
E_x = e_data.values[:, 1]
E_y = e_data.values[:, 2]
E_z = e_data.values[:, 3]
pos_boxes = [
    [8.91304348,	1.20652174,	0.61669004],
    [6.91304348,	-1.39347826, 0.21669004],
    [-1.68695652,	1.20652174,	-0.28330996],
    [3.11304348,	0.60652174,	-0.18330996],
    [-5.28695652,	-0.29347826,	0.41669004],
    [-2.08695652,	-1.49347826,	0.21669004],
    ]
box_xyz = [[1.5, 0.9, 0.3],
            [2.2, 0.8, 1.1],
            [2.4, 1.1, 0.9],
            [1.7, 1.3, 1.2],
            [2.4, 1.2, 1],
            [2.4, 1, 0.5], ]

needs = need_data.values[:, 1]
boxes_x = np.array([1.5, 2.2, 2.4, 1.7, 2.4, 2.4])
boxes_y = np.array([0.9, 0.8, 1.1, 1.3, 1.2, 1])
boxes_z = np.array([0.3, 1.1, 0.9, 1.2, 1, 0.5])

# print(needs)
# need带转换为一分钟的最大值（现在是均匀采样）
oil_density = 850
oil_mass0 = np.array([0.3, 1.5, 2.1, 1.9, 2.6, 0.8])*oil_density



gears = np.array([0, 0.25, 0.5, 0.75, 1])
gears_matrix = np.array([[i, j, k]for i in gears for j in gears for k in gears])
# print(gears_matrix.shape)
main_boxes = [2, 3, 4, 5]

box_choice = np.array([
    [2, 3, 1], [2, 3, 6],
    [2, 4, 1], [2, 4, 6],
    [2, 5, 1], [2, 5, 6],
    [3, 4, 1], [3, 4, 6],
    [3, 5, 1], [3, 5, 6],
    [4, 5, 1], [4, 5, 6],
    [2, 1, 6],
    [3, 1, 6],
    [4, 1, 6],
    [5, 1, 6],
    ])

# print(box_choice.shape)


def check_need(boxes, gears, need):
    suply = 0
    check_flag = False
    for i in range(len(boxes)):
        if boxes[i] in main_boxes:
            suply += v_max[boxes[i]-1]*gears[i]
    if suply > need:
        check_flag = True

    return check_flag




class Point:
    def __init__(self, oil_ms, open_boxes, gears, last_time):
        self.oil_ms = oil_ms
        self.open_boxes = open_boxes
        self.gears = gears
        self.oil_vs = self.oil_ms / 850
        self.centroid = self.calCentroid()
        self.last_time = last_time

    def calCentroid(self):
        sum_x_mass = 0
        sum_y_mass = 0
        sum_z_mass = 0
        sum_mass = sum(self.oil_ms)
        for i in range(6):
            box_centroid = (pos_boxes[i][0], pos_boxes[i][1], pos_boxes[i][2] + self.oil_vs[i]/(box_xyz[i][0]*box_xyz[i][1]*2) - box_xyz[i][2]/2)
            sum_x_mass += box_centroid[0] * self.oil_ms[i]
            sum_y_mass += box_centroid[1] * self.oil_ms[i]
            sum_z_mass += box_centroid[2] * self.oil_ms[i]

        centroid_x = sum_x_mass/sum_mass
        centroid_y = sum_y_mass/sum_mass
        centroid_z = sum_z_mass/sum_mass

        return centroid_x, centroid_y, centroid_z


def get_next_point(curr_point, need):
    next_points = []
    if curr_point.last_time >= 60:
        # 可以改变openboxes
        for boxes in box_choice:
            for gear in gears_matrix:
                suply = 0
                positive = 0
                for i in range(len(boxes)):

                    if boxes[i] in main_boxes:
                        suply += v_max[boxes[i] - 1] * gear[i]
                    if curr_point.oil_ms[boxes[i]-1] > v_max[boxes[i] - 1] * gear[i]:
                        positive += 1



                if suply >= need and positive == 3:
                    new_oil_ms = curr_point.oil_ms.copy()

                    for box in boxes:
                        if box == 1:
                            new_oil_ms[0] -= v_max[0] * gear[list(boxes).index(box)]

                            new_oil_ms[1] += v_max[1] * gear[list(boxes).index(box)]
                        if box == 6:
                            new_oil_ms[5] -= v_max[5] * gear[list(boxes).index(box)]
                            new_oil_ms[4] += v_max[4] * gear[list(boxes).index(box)]
                        if box in main_boxes:
                            new_oil_ms[box-1] -= v_max[box-1] * gear[list(boxes).index(box)]

                    new_lastime = curr_point.last_time
                    if list(boxes) != list(curr_point.open_boxes):
                        new_lastime = 0
                    point1 = Point(new_oil_ms, boxes, gear, new_lastime)
                    next_points.append(point1)
    else:
        # 不可以改变openboxes
        # print(1)
        boxes = curr_point.open_boxes
        # print(boxes)
        for gear in gears_matrix:
            suply = 0
            positive = 0
            for i in range(len(boxes)):

                if boxes[i] in main_boxes:
                    suply += v_max[boxes[i] - 1] * gear[i]
                if curr_point.oil_ms[boxes[i] - 1] > v_max[boxes[i] - 1] * gear[i]:
                    positive += 1

            if suply >= need and positive == 3:
                new_oil_ms = curr_point.oil_ms.copy()
                for box in boxes:
                    if box == 1:
                        new_oil_ms[0] -= v_max[0] * gear[list(boxes).index(box)]
                        new_oil_ms[1] += v_max[1] * gear[list(boxes).index(box)]
                    if box == 6:
                        new_oil_ms[5] -= v_max[5] * gear[list(boxes).index(box)]
                        new_oil_ms[4] += v_max[4] * gear[list(boxes).index(box)]
                    if box in main_boxes:
                        new_oil_ms[box - 1] -= v_max[box - 1] * gear[list(boxes).index(box)]

                new_last_time = curr_point.last_time+1
                point1 = Point(new_oil_ms, boxes, gear, new_last_time)
                next_points.append(point1)


    # print(len(next_points))
    # for point in next_points:
    #     print(point.oil_ms)

    return next_points

select_num = 50
road0 = [Point(oil_mass0, [0, 0, 0], [0, 0, 0], 60)]
group0 = [road0]

for time in range(len(needs)):

    group1 = []

    for road in group0:
        # print(road)
        next_points = get_next_point(road[-1], 0.01)

        for point in next_points:
            road1 = road.copy()
            road1.append(point)
            group1.append(road1)

    cost_list = []
    for road in group1:
        curr_centroid = road[-1].centroid
        cost_curr = (curr_centroid[0]-E_x[time])**2 + (curr_centroid[1]-E_y[time])**2 + (curr_centroid[2]-E_z[time])**2
        cost_list.append(cost_curr)

    sorted_indices = np.argsort(cost_list)[:select_num]
    group2 = []
    for i in range(len(sorted_indices)):
        group2.append(group1[sorted_indices[i]])


    group0 = group2
    print(time, len(group0))

road_best = group0[0]
print('road_best中记录了%ds的数据' % len(road_best))
road_record = {
    'centroid_x': [0],
    'centroid_y': [0],
    'centroid_z': [0],
    'oil_box1_m': [],
    'oil_box2_m': [],
    'oil_box3_m': [],
    'oil_box4_m': [],
    'oil_box5_m': [],
    'oil_box6_m': [],
    'oil_box1_gear': [],
    'oil_box2_gear': [],
    'oil_box3_gear': [],
    'oil_box4_gear': [],
    'oil_box5_gear': [],
    'oil_box6_gear': [],
    'oil_box1_kg/s': [],
    'oil_box2_kg/s': [],
    'oil_box3_kg/s': [],
    'oil_box4_kg/s': [],
    'oil_box5_kg/s': [],
    'oil_box6_kg/s': [],
               }
max_cost = 0
for time, point in enumerate(road_best):

    for i in range(1, 7):
        road_record['oil_box%d_m' % i].append(point.oil_ms[i-1])
        if i in point.open_boxes:
            road_record['oil_box%d_gear' % i].append(point.gears[list(point.open_boxes).index(i)])
            road_record['oil_box%d_kg/s' % i].append((v_max[i-1])*point.gears[list(point.open_boxes).index(i)])
        else:
            road_record['oil_box%d_gear' % i].append(0)
            road_record['oil_box%d_kg/s' % i].append(0)

    if time >= 1:
        curr_centroid = point.centroid
        road_record['centroid_x'].append(curr_centroid[0])
        road_record['centroid_y'].append(curr_centroid[1])
        road_record['centroid_z'].append(curr_centroid[2])
        cost_curr = (curr_centroid[0]-E_x[time-1])**2 + (curr_centroid[1]-E_y[time-1])**2 + (curr_centroid[2]-E_z[time-1])**2
        if cost_curr >= max_cost:
            max_cost = cost_curr

print('最大的损失函数值为：', max_cost)
road_record = pd.DataFrame(road_record)
road_record.to_excel('answers\question2best_road_res%d.xlsx'%select_num)


# for time in range(len(needs)):
#     group1 = []
#     for road in group0:
#         point_curr = road[-1]
#
#
# for time in range(len(needs)):
#
#
#     solutions = []
#     for boxes in box_choice:
#         for gear in gears_matrix:
#             # print(boxes, gear)
#
#             check_flag = check_need(boxes, gear, needs[time])
#             if check_flag == True:
#                 # 通过检测是可行方案
#                 # 在2000种方案种筛选出可行的方案
#                 solutions.append([boxes, gears])
#     print(time, len(solutions))

    # for solution in solutions:




