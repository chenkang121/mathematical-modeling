import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

text = ['m1', 'm2', 'm3', 'm4', 'm5', 'm6', '原点']


plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']

pos_boxes = np.array([
    [8.91304348,	1.20652174,	0.61669004],
    [6.91304348,	-1.39347826, 0.21669004],
    [-1.68695652,	1.20652174,	-0.28330996],
    [3.11304348,	0.60652174,	-0.18330996],
    [-5.28695652,	-0.29347826,	0.41669004],
    [-2.08695652,	-1.49347826,	0.21669004],
    [0, 0, 0]
    ])

ax = plt.axes(projection='3d')
for i in range(pos_boxes.shape[0]):

    ax.scatter3D(pos_boxes[i, 0], pos_boxes[i, 1], pos_boxes[i, 2], s=200)
    ax.text(pos_boxes[i, 0]+1, pos_boxes[i, 1], pos_boxes[i, 2]+0.1, text[i], fontsize=20)
# ax.scatter3D(0, 0, 0, c='r')
plt.show()



