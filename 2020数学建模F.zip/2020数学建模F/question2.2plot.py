import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

data = pd.read_excel('data\\question2_visual_centroid.xlsx')
val = data.values

print(data)
ax = plt.axes(projection='3d')
ax.scatter3D(val[:, 0], val[:, 1], val[:, 2], alpha=0.02)
ax.scatter3D(val[:, 3], val[:, 4], val[:, 5], alpha=0.02)


plt.show()
ax = plt.axes(projection='3d')


ax.scatter3D(val[:, 6], val[:, 7], val[:, 8], alpha=0.02)
ax.scatter3D(val[:, 3], val[:, 4], val[:, 5], alpha=0.02)

plt.show()
