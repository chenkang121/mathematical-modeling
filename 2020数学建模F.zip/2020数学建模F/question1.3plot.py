import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

data = pd.read_excel('answers\\question1_answer.xlsx', index_col=0)
print(data)
val = data.values
ax = plt.axes(projection='3d')
ax.scatter3D(val[:, 0], val[:, 1], val[:, 2], alpha=0.2, c=list(range(val.shape[0]))[::-1])
ax.scatter3D(0, 0, 0, c='r')
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
plt.show()
