import pandas as pd
import numpy as np

data1 = pd.read_excel('data\附件2-问题1数据.xlsx', sheet_name='油箱供油曲线')
data2 = pd.read_excel('data\附件2-问题1数据.xlsx', sheet_name='飞行器俯仰角')
box_data = pd.read_excel('data\\附件1-飞行器参数.xlsx', sheet_name='Sheet1')
oil_density = 850
print(data1)
# print(data2)
boxes = {'box1': [0.3*oil_density], 'box2': [1.5*oil_density], 'box3': [2.1*oil_density],
        'box4': [1.9*oil_density], 'box5': [2.6*oil_density], 'box6': [0.8*oil_density],
        'alpha': [0]}

for i in range(data1.shape[0]):
    box1_ = boxes['box1'][-1] - data1.iloc[i, 1]
    box2_ = boxes['box2'][-1] - data1.iloc[i, 2] + data1.iloc[i, 1]
    box3_ = boxes['box3'][-1] - data1.iloc[i, 3]
    box4_ = boxes['box4'][-1] - data1.iloc[i, 4]
    box5_ = boxes['box5'][-1] - data1.iloc[i, 5] + data1.iloc[i, 6]
    box6_ = boxes['box6'][-1] - data1.iloc[i, 6]
    boxes['box1'].append(box1_)
    boxes['box2'].append(box2_)
    boxes['box3'].append(box3_)
    boxes['box4'].append(box4_)
    boxes['box5'].append(box5_)
    boxes['box6'].append(box6_)
    boxes['alpha'].append(data2.iloc[i, 1])
    # print(data1.iloc[i, 1])

boxes = pd.DataFrame(boxes)
boxes.to_excel('data\question1_data_processed.xlsx')