
import matplotlib.pyplot as plt
import numpy as np


x = np.linspace(0, 100, 101)
y = np.exp(-x/3)
y[5:10] = y[5]
y[10:101] = y[10]
y[3:5] = y[3]
print(y)
plt.plot(x, y)
plt.show()