import pandas as pd
import numpy as np


posCentriod_time = pd.read_excel('data\\question1.1posCentriod_time.xlsx', index_col=0)
print(posCentriod_time)

pos_answer = {'x': [], 'y': [], 'z': [], 'total_mass': []}
for i in range(posCentriod_time.shape[0]):
    sum_x_plus_mass = 0
    sum_y_plus_mass = 0
    sum_z_plus_mass = 0
    sum_mass = 3000
    for j in range(6):
        sum_x_plus_mass += posCentriod_time.iloc[i, j * 4 + 0] * posCentriod_time.iloc[i, j * 4 + 3]
        sum_y_plus_mass += posCentriod_time.iloc[i, j * 4 + 1] * posCentriod_time.iloc[i, j * 4 + 3]
        sum_z_plus_mass += posCentriod_time.iloc[i, j * 4 + 2] * posCentriod_time.iloc[i, j * 4 + 3]
        sum_mass += posCentriod_time.iloc[i, j * 4 + 3]

    x = sum_x_plus_mass/sum_mass
    y = sum_y_plus_mass/sum_mass
    z = sum_z_plus_mass/sum_mass
    print(x, y, z)
    pos_answer['x'].append(x)
    pos_answer['y'].append(y)
    pos_answer['z'].append(z)
    pos_answer['total_mass'].append(sum_mass)

pos_answer = pd.DataFrame(pos_answer)
pos_answer.to_excel('answers\\question1_answer.xlsx')